SELECT Count(allekerdezes.orszag)
FROM (SELECT … FROM …) AS allekerdezes;
